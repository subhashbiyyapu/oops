import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Books} from "./assignment/booksobj";
import { Employee } from './employeeobj';

@Injectable({
  providedIn: 'root'
})
export class BooksService {

  localurl="./assets/books.json"

  constructor(private http:HttpClient) 
  {

   }
   httpOptions={
     headers:new HttpHeaders({
       'Content-Type':'application/json'
     })
   }
  
  GetBooks():Observable<Books>
  {
    return this.http.get<Books>(this.localurl);
  }
}
