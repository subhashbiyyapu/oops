import { Component, OnInit } from '@angular/core';
import { templateJitUrl } from '@angular/compiler';
import {Employee} from './employeeobj';
import  { DataserviceService} from './dataservice.service'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent  implements OnInit{
  somedata:string=" ";
  localbooklist:any[];
  emp:Employee[]=[];
  index=0;
  tempemp:Employee=null;
  uptemp:Employee=null;
  uptemp1:Employee=null;
  id1=" ";
  name1=" ";
  salary1=" ";
  department1=" ";

    i=0;
  title = 'employeedemo';
  id=" ";
  name=" ";
  salary=" ";
  department=" ";
  flag:boolean=false;
  updateflag:boolean=false;
   temp:Employee;
  constructor(private ds:DataserviceService)
  {
   
  }
  ngOnInit()
  {
   
    this.ds.GetLocalBooks().subscribe((data:any)=>{
      this.emp=data;
      console.log(data[0].id);
      })
    //this.loadBooks();


  }

  
  
  alertload():void{
    //alert(this.id+" "+this.name+" "+this.salary+" "+this.department);
    this.temp=new Employee();
   this. temp.id=this.id;
    this.temp.name=this.name;
   this. temp.salary=this.salary;
    this.temp.department=this.department;
    this.emp.push(this.temp);
    this.flag=true;
    this.id="";
    this.name="";
    this.salary="";
    this.department="";
  
  }
  onupdate(event)

  { 
    //this.i=event.toElement.id;
    
    this.i=this.emp.findIndex(x=>x.id===event.id );
    this.uptemp1=this.emp[this.i];
    console.log(this.i+"index"+this.uptemp1.id+this.uptemp1.name+this.uptemp1.salary+this.uptemp1.id)
    this.id1=this.uptemp1.id;
    this.name1=this.uptemp1.name;
    this.salary1=this.uptemp1.salary;
    this.department1=this.uptemp1.department;
    this.updateflag=true; 
  
  }
  onchangeupdate()
  {
    this.emp[this.i].id=this.id1;
    this.emp[this.i].name=this.name1;
    this.emp[this.i].salary=this.salary1;
    this.emp[this.i].department=this.department1;
    this.tempemp=this.emp[this.i];
  }
  onchangedelete(event:Employee)
  {
    let k=this.emp.findIndex(x=>x.id===event.id );
    if(k!=-1)
    {
      this.emp.splice(k,1);
    }
    // this.i=event.toElement.id;
    // this.uptemp1=this.emp[this.i];
    // this.emp.splice(this.i,this.i+1);
  }

receivedmessage;
receivemessage($event:any)
{
this.receivedmessage=$event;
}

  
  

}

