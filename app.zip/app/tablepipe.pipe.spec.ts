import { TablepipePipe } from './tablepipe.pipe';

describe('TablepipePipe', () => {
  it('create an instance', () => {
    const pipe = new TablepipePipe();
    expect(pipe).toBeTruthy();
  });
});
