import { Component, OnInit, Input, Output ,EventEmitter} from '@angular/core';


@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
@Input() namei;
@Output() emitter=new EventEmitter<string>();  
messagetobesent:string="hey there!";


  constructor() { }

  ngOnInit(): void {
  }
  sendmessage()
  {
    this.emitter.emit("hey there");

  }
 

}
