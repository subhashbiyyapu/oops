import { Component, OnInit } from '@angular/core';
import { BooksService } from '../books.service';
import {Books} from "./booksobj"

@Component({
  selector: 'app-assignment',
  templateUrl: './assignment.component.html',
  styleUrls: ['./assignment.component.css']
})
export class AssignmentComponent implements OnInit {
  idvalue:string="";
  authorvalue:string="";
  yearvalue:string="";
  namevalue:string="";
  b:Books[];
  constructor(private ds:BooksService)
  {
   
  }
  ngOnInit()
  {
   
    this.ds.GetBooks().subscribe((data:any)=>{
      this.b=data;
      console.log(data[0].id);
      })
    //this.loadBooks();


  }
  keyevent(event)
  {
  console.log(event);
  console.log(this.idvalue+"is the value");
  }

}
