

export class Books{
id;
title;
year;
author;

}