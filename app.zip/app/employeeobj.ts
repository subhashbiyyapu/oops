export class Employee
{
    id;
    name;
    salary;
    department;

}